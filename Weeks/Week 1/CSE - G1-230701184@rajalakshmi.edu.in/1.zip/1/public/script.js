// Wait for DOM to be fully loaded before attaching event listeners
document.addEventListener('DOMContentLoaded', function() {
    const highlightBtn = document.getElementById('highlightBtn');
    const textPara = document.getElementById('textPara');
    
    if (highlightBtn && textPara) {
        highlightBtn.addEventListener('click', function() {
            toggleHighlight();
        });
    }
});

// Function to toggle highlight on the text paragraph
function toggleHighlight() {
    const textPara = document.getElementById('textPara');
    
    // Check if element exists to prevent errors
    if (!textPara) {
        console.error('Text paragraph element not found');
        return;
    }
    
    // Get current background color
    const currentBgColor = window.getComputedStyle(textPara).backgroundColor;
    
    // Toggle between yellow highlight and transparent/no background
    if (currentBgColor === 'rgb(255, 255, 0)') {
        // Remove highlight - set to transparent
        textPara.style.backgroundColor = 'transparent';
    } else {
        // Apply yellow highlight
        textPara.style.backgroundColor = 'rgb(255, 255, 0)';
    }
}

// Alternative approach using CSS classes (commented out)
/*
function toggleHighlightWithClass() {
    const textPara = document.getElementById('textPara');
    
    if (!textPara) {
        console.error('Text paragraph element not found');
        return;
    }
    
    textPara.classList.toggle('highlighted');
}
*/
