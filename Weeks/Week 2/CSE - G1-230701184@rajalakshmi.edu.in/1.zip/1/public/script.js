//Start
document.getElementById("addMaterialBtn").addEventListener("click",()=>{
    let val=document.getElementById("materialName").value
    if(val==""){
        document.getElementById("error-message").textContent="Please fill out all fields!"
    }
    addNewRow()
})

function validate(){
    let val=document.getElementById("materialName").value
    if(val==""){
        document.getElementById("error-message").textContent="Please fill out all fields!"
    }
    addNewRow()
}
function addNewRow(){
    let materialName=document.getElementById("materialName").value
    let category=document.getElementById("category").value
    let quantity=document.getElementById("quantity").value
    let supplierName=document.getElementById("supplierName").value
    let costPerUnit=document.getElementById("costPerUnit").value

    row=document.getElementById("materialTable tbody").insertRow()

    row.insertCell(0).textContent=materialName;
    row.insertCell(1).textContent=category;
    row.insertCell(2).textContent=quantity;
    row.insertCell(3).textContent=supplierName;
    row.insertCell(4).textContent=costPerUnit;

    let tot=document.getElementById("totalProducts").value
    document.getElementById("totalProducts").textContent=tot+1
    let most=document.getElementById("exp").value
    if(most<costPerUnit){
        document.getElementById("mostExpensive").textContent=materialName
        document.getElementById("exp").textContent=costPerUnit
    }
}