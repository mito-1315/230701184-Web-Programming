// config.js
 export const apiUrl = 'dummyUrl';

