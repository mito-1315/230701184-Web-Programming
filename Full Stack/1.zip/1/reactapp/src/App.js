import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import Login from './Components/Login';
import Register from './Components/Register';
import ErrorPage from './Components/ErrorPage';
import DisplayRecipes from './Foodie/DisplayRecipes';
import ManageRecipe from './Chef/ManageRecipe';
import CreateRecipe from './Chef/CreateRecipe';
import './App.css';
function App() {
    // Check if user is authenticated
    const isAuthenticated = () => {
        const token = localStorage.getItem('token');
        return token !== null;
    };
    // Get user role from localStorage
    const getUserRole = () => {
        const userData = localStorage.getItem('userData');
        if (userData) {
            try {
                const user = JSON.parse(userData);
                return user.role;
            } catch (error) {
                return null;
            }
        }
        return null;
    };
    // Protected Route Component
    const ProtectedRoute = ({ children, requiredRole = null }) => {
        const authenticated = isAuthenticated();
        const userRole = getUserRole();
        if (!authenticated) {
            return <Navigate to="/login" replace />;
        }
        if (requiredRole && userRole !== requiredRole) {
            return <Navigate to="/error" replace />;
        }
        return children;
    };
    // Public Route Component (redirect if already authenticated)
    const PublicRoute = ({ children }) => {
        const authenticated = isAuthenticated();
        const userRole = getUserRole();
        if (authenticated) {
            // Redirect based on role
            if (userRole === 'admin') {
                return <Navigate to="/manage-recipes" replace />;
            } else {
                return <Navigate to="/recipes" replace />;
            }
        }
        return children;
    };
    return (
        <div className="App">
            <Router>
                <Routes>
                    {/* Public Routes */}
                    <Route
                    path="/login"
                    element={
                        <PublicRoute>
                            <Login />
                            </PublicRoute>
                    }
                    />
                    <Route
                    path="/register"
                    element={
                        <PublicRoute>
                            <Register />
                            </PublicRoute>
                    }
                    />
                    {/* Protected Routes */}
                    <Route
                    path="/recipes"
                    element={
                        <ProtectedRoute>
                            <DisplayRecipes />
                            </ProtectedRoute>
                    }
                    />
                    <Route
                    path="/manage-recipes"
                    element={
                        <ProtectedRoute requiredRole="admin">
                            <ManageRecipe />
                            </ProtectedRoute>
                    }
                    />
                    <Route
                    path="/create-recipe"
                    element={
                        <ProtectedRoute requiredRole="admin">
                            <CreateRecipe />
                            </ProtectedRoute>
                    }
                    />
                    <Route
                    path="/edit-recipe/:id"
                    element={
                        <ProtectedRoute requiredRole="admin">
                            <CreateRecipe />
                            </ProtectedRoute>
                    }
                    />
                    {/* Error Route */}
                    <Route path="/error" element={<ErrorPage />} />
                    {/* Default Routes */}
                    <Route
                    path="/"
                    element={
                        isAuthenticated() ? (
                            getUserRole() === 'admin' ? (
                                <Navigate to="/manage-recipes" replace />
                            ) : (
                                <Navigate to="/recipes" replace />
                            )
                        ) : (
                            <Navigate to="/login" replace />
                        )
                    }
                    />
                    {/* Catch all route - redirect to error */}
                    <Route path="*" element={<Navigate to="/error" replace />} />
                    </Routes>
                    </Router>
                    </div>
    );
                }
                export default App;
                