const mongoose = require('mongoose');
const recipeSchema = new mongoose.Schema({
    title: {
        type: String,
        required: [true, 'Title is required'],
        trim: true
    },
    category: {
        type: String,
        required: [true, 'Category is required'],
        enum: {
            values: ['Breakfast', 'Lunch', 'Dinner', 'Snacks', 'Dessert'],
            message: 'Category must be one of: Breakfast, Lunch, Dinner, Snacks, Dessert'
        }
    },
    difficulty: {
        type: String,
        required: [true, 'Difficulty is required'],
        enum: {
            values: ['Easy', 'Medium', 'Hard'],
            message: 'Difficulty must be one of: Easy, Medium, Hard'
        }
    },
    prepTimeInMinutes: {
        type: Number,
        required: [true, 'Prep time is required'],
        min: [1, 'Prep time must be at least 1 minute']
    },
    cookTimeInMinutes: {
        type: Number,
        required: [true, 'Cook time is required'],
        min: [1, 'Cook time must be at least 1 minute']
    },
    servings: {
        type: Number,
        required: [true, 'Servings is required'],
        min: [1, 'Servings must be at least 1']
    },
    cuisine: {
        type: String,
        enum: {
            values: ['American', 'Italian', 'French', 'Chinese', 'Japanese', 'Indian', 'Mexican', 'Thai', 'Mediterranean', 'Other'],
            message: 'Cuisine must be a valid cuisine type'
        }
    },
    ingredients: {
        type: [String],
        required: [true, 'Ingredients are required'],
        validate: {
            validator: function(v) {
                return v && v.length > 0;
            },
            message: 'At least one ingredient is required'
        }
    },
    instructions: {
        type: [String],
        required: [true, 'Instructions are required'],
        validate: {
            validator: function(v) {
                return v && v.length > 0;
            },
            message: 'At least one instruction is required'
        }
    },
    tags: {
        type: [String],
        default: []
    },
    notes: {
        type: String,
        default: ''
    },
    nutritionalInfo: {
        calories: {
            type: Number,
            min: 0
        },
        protein: {
            type: Number,
            min: 0
        },
        carbs: {
            type: Number,
            min: 0
        },
        fat: {
            type: Number,
            min: 0
        }
    },
    userId: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: [true, 'User ID is required']
    }
}, {
    timestamps: true
});
module.exports = mongoose.model('Recipe', recipeSchema);
