const express = require('express');
const { getAllRecipes, addRecipe, updateRecipe, deleteRecipe, getRecipeById, getRecipesByUserId } = require('../controllers/recipeController');
const { validateToken } = require('../authUtils');
const router = express.Router();
// Get all recipes (with optional sorting)
router.post('/all', getAllRecipes);
// Add a new recipe (protected route)
router.post('/add', validateToken, addRecipe);
// Update a recipe by ID (protected route)
router.put('/update/:id', validateToken, updateRecipe);
// Delete a recipe by ID (protected route)
router.delete('/delete/:id', validateToken, deleteRecipe);
// Get a recipe by ID
router.get('/:id', getRecipeById);
// Get recipes by user ID (with optional category filter)
router.post('/user', validateToken, getRecipesByUserId);
module.exports = router;
