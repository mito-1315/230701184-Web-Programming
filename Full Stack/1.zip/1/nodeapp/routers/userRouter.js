const express = require('express');
const { getUserByUsernameAndPassword, addUser, getAllUsers } = require('../controllers/userController');
const { validateToken } = require('../authUtils');
const router = express.Router();
// User login (get user by email and password)
router.post('/login', getUserByUsernameAndPassword);
// User registration (add new user)
router.post('/register', addUser);
// Get all users (protected route)
router.get('/all', validateToken, getAllUsers);
module.exports = router;
